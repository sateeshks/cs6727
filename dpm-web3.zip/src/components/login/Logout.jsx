import {useEffect, useState} from "react";
import { useNavigate, Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {loginAction, logout} from "./loginSlice";
import {deleteProfile } from "../profile/ProfileSlice";
import "../../App.css"
import Login from "./Login";
const Logout = () => {
    //Logout before login
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { token, fetchStatus } = useSelector((state) => state.login);
    
    useEffect( () => {
        if (token) {
            dispatch(deleteProfile());
            dispatch(logout());

        }
        navigate("/");
    }, [token] ); //Not sure

}
export default Logout;