import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { initialCheckStatus, base64urlToUint8array, uint8arrayToBase64url, displayError, followRedirect, throwError, checkStatus, WebAuthServerError } from "../../helpers/custom";
//import {AuthHeader} from "../../data/auth_header"
import {useSelector} from "react-redux";
import {profileGetAction} from "../profile/ProfileSlice";
/*export const getDomainProfileAction = createAsyncThunk("getProfile", async ( domain, { getState }) => {
    const state = getState();
    const token  = state.login.token;
    console.log("profile get action  token is   "+token);
    let profile = await   fetch('http://localhost:9090/genpass/user/profile?domain='+domain, {
        headers: {
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        },
        method: 'GET'
    }).catch((error) => {

        console.log("error loading profile");
    })
    profile = await initialCheckStatus(profile);
    return profile;
});*/
export const pwdgenAction = createAsyncThunk("pwdgen", async (profile, { getState }) => {
    const state = getState();
    const token  = state.login.token;
    console.log("profileSaveAction token is   "+token);
    let password = await fetch('http://localhost:9090/genpass/user/password', {
        headers: {
            'Authorization': 'Bearer '+token,
            'Content-Type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify(profile)
    });
    password = await initialCheckStatus(password);
    let result={'domain':profile.domain,'password':password.password};
    return result;
});

const passwordSlice = createSlice({
    name: "password-reducer",
    initialState: {
        pwd: {
            domain: '',
            password: ''
        },
        dprofile:undefined
    },
    reducers: {
        "generate": (action, state) => {
            state.pwd = action.payload;

        },
        "getPassword": (action, state) => {
            return state.pwd;
        },
        "deleteProfilePassword": (action, state) => {
            state.pwd = undefined;

        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(pwdgenAction.fulfilled, (state, action) => {
                state.pwd = action.payload;
                               state.fetchStatus = 'success';
                console.log("password generated   " + state.pwd.password);
            })
            .addCase(pwdgenAction.pending, (state) => {
                state.fetchStatus = 'loading';
            })
            .addCase(pwdgenAction.rejected, (state) => {
                state.pwd = undefined;
                state.fetchStatus = 'error';
            })
    },
});

export default passwordSlice;