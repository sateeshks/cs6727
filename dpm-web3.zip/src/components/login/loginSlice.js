import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { initialCheckStatus, base64urlToUint8array, uint8arrayToBase64url, displayError, followRedirect, throwError, checkStatus, WebAuthServerError } from "../../helpers/custom";


export const loginAction = createAsyncThunk("login", async (params) => {

    const response = await fetch('http://localhost:9090/genpass/login', {
        headers: {
            'Content-Type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify(params)
    });
    const credentialGetJson = await initialCheckStatus(response);
    const credentialGetOptions = {
        publicKey: {
            ...credentialGetJson.publicKey,
            allowCredentials: credentialGetJson.publicKey.allowCredentials
                && credentialGetJson.publicKey.allowCredentials.map(credential => ({
                    ...credential,
                    id: base64urlToUint8array(credential.id),
                })),
            challenge: base64urlToUint8array(credentialGetJson.publicKey.challenge),
            extensions: credentialGetJson.publicKey.extensions,
        }
    };

    let publicKeyCredential = await  navigator.credentials.get(credentialGetOptions);
    const encodedResult = {
        type: publicKeyCredential.type,
        id: publicKeyCredential.id,
        response: {
            authenticatorData: uint8arrayToBase64url(publicKeyCredential.response.authenticatorData),
            clientDataJSON: uint8arrayToBase64url(publicKeyCredential.response.clientDataJSON),
            signature: uint8arrayToBase64url(publicKeyCredential.response.signature),
            userHandle: publicKeyCredential.response.userHandle && uint8arrayToBase64url(publicKeyCredential.response.userHandle),
        },
        clientExtensionResults: publicKeyCredential.getClientExtensionResults(),
    };
    const finishLogin = {
        credential: JSON.stringify(encodedResult),
        username: params.username
    };
    console.log(JSON.stringify(finishLogin))
    const welcomeResp = await fetch("http://localhost:9090/genpass/welcome", {
        headers: {
            'Content-Type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify(finishLogin)
    });
    const tokenResp = await initialCheckStatus(welcomeResp);
    //localStorage.setItem("token", tokenResp.token);
    return tokenResp.token;
});


const loginSlice = createSlice({
    name: "login-reducer",
    initialState: {
        token: "",
        fetchStatus: ""
    },
    reducers: {
        "login": (action, state) => {
            state.token = action.payload;

        },
        "getToken": (action, state) => {
            return state.token;
        },
        "logout": (action, state) => {
            state.token = "";
            state.fetchStatus= "";

        },
    },
    extraReducers: (builder) => {
        builder
          .addCase(loginAction.fulfilled, (state, action) => {
            state.token = action.payload;
             state.fetchStatus = 'success';
            console.log("*** token is " + state.token);
            console.log("*** fetchStatus is " + state.fetchStatus);
          })
          .addCase(loginAction.pending, (state) => {
            state.fetchStatus = 'Processing...';
          })
          .addCase(loginAction.rejected, (state, action) => {
            state.token = "";
            state.fetchStatus = 'Error!!! Please try after sometime';
            switch(action.error?.message) {
                case "400":
                    state.fetchStatus = "Error!!! Bad request";
                    break;
                case "401":
                    state.fetchStatus = "Error!!! Login failed.";
                    break;
                default:
                    state.fetchStatus = "Unknown error!!";
            }
          })
      },
});
export const { login, getToken, logout ,} = loginSlice.actions;

export default loginSlice;