import {useDispatch, useSelector} from "react-redux";
import Login from "./components/login/Login";
import Profile from "./components/profile/Profile";
import Logout from "./components/login/Logout";
import Registration from "./components/registration/Registration";
import { BrowserRouter as Router, Routes, Route, Link, NavLink, Redirect } from "react-router-dom";
import Pwdgen from "./components/password/pwdgen";
import About from "./components/about/About";


function App() {
  const dispatch = useDispatch();
  const { token } = useSelector((state) => state.login);
 // const { profile } = useSelector((state) => state.profile);
  /*  useEffectOnce((effect)=> {
        if(token){
            // componentDidMount(){
            fetch('http://localhost:9090/genpass/user/profile?domain=default', {
                headers: {
                    'Authorization': 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                method: 'GET'
            }).then(response =>    dispatch(setProfile(response)))
                .catch((error) => {

                    console.log("error loading profile");
                })
        }
    },[token]);*/

  return (
    <main className='container'>

      <header>
        <div style={{height: "100px"}}>
        <nav>
          <ul>
            <li><strong>DPM</strong></li>
          </ul>

          <ul>
            {(token && (
              <>
                <li><NavLink to="passwordgen">Password</NavLink></li>
                <li><NavLink to="profile">Profile</NavLink></li>
                <li><NavLink to="logout">Logout</NavLink></li>
              </>
            ))}
            <li><NavLink to="about">About</NavLink></li>
          </ul>
        </nav>
        </div>
      </header>

      <main>
        <Routes>
          <Route path="/" Component={Login} />
          <Route path="/login" Component={Login} />
          <Route path="/profile" Component={Profile} />
          <Route path="/passwordgen" Component={Pwdgen} />
          <Route path="/register" Component={Registration} />
          <Route path="/logout" Component={Logout} />
          <Route path="/about" Component={About} />
        </Routes>
      </main>


      <footer>
        <h6 style={{textAlign: "center"}}>&copy; Protected website</h6>
      </footer>

    </main>
  );
}

export default App;
