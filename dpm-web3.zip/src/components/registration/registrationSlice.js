import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { initialCheckStatus, base64urlToUint8array, uint8arrayToBase64url, displayError, followRedirect, throwError, checkStatus, WebAuthServerError } from "../../helpers/custom";

export const registrationAction = createAsyncThunk("register", async (user) => {
    const response = await fetch('http://localhost:9090/genpass/register', {
        headers: {
            'Content-Type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify(user)
    });
    const credentialCreateJson = await initialCheckStatus(response);
    const credentialCreateOptions ={
        publicKey: {
            ...credentialCreateJson.publicKey,
            challenge: base64urlToUint8array(credentialCreateJson.publicKey.challenge),
            user: {
                ...credentialCreateJson.publicKey.user,
                id: base64urlToUint8array(credentialCreateJson.publicKey.user.id),
            },
            excludeCredentials: credentialCreateJson.publicKey.excludeCredentials.map(credential => ({
                ...credential,
                id: base64urlToUint8array(credential.id),
            })),
            extensions: credentialCreateJson.publicKey.extensions,
        },
    };
    const publicKeyCredential = await navigator.credentials.create(credentialCreateOptions);
    const encodedResult = {
        type: publicKeyCredential.type,
        id: publicKeyCredential.id,
        response: {
            attestationObject: uint8arrayToBase64url(publicKeyCredential.response.attestationObject),
            clientDataJSON: uint8arrayToBase64url(publicKeyCredential.response.clientDataJSON),
            transports: publicKeyCredential.response.getTransports && publicKeyCredential.response.getTransports() || [],
        },
        clientExtensionResults: publicKeyCredential.getClientExtensionResults(),
    };
    user.credential = encodedResult;
    console.log(JSON.stringify(user));
    const finshAuthResp = await fetch("http://localhost:9090/genpass/finishauth", {
        headers: {
            'Content-Type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify(user)
    });
    const finshAuth = await initialCheckStatus(finshAuthResp);
    //localStorage.setItem("token", tokenResp.token);
    return finshAuth;


});

const registrationSlice = createSlice({
    name: "register-reducer",
    initialState: {
        user: undefined
    },
    reducers: {
        "register": (action, state) => {
            state.user = action.payloadl;
        },
        "getUser": (action, state) => {
            return state.user;
        },

    },
    extraReducers: (builder) => {
        builder
            .addCase(registrationAction.fulfilled, (state, action) => {
                state.user = action.payload.user;
                state.fetchStatus = 'success';
                console.log("user registered is " + state.user.name);
            })
            .addCase(registrationAction.pending, (state) => {
                state.fetchStatus = 'loading';
            })
            .addCase(registrationAction.rejected, (state) => {
                state.user = undefined;
                state.fetchStatus = 'error';
            })
    },
});

export default registrationSlice;