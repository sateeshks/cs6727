import { profileGetAction } from "../profile/ProfileSlice";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import React, { useState, useEffect } from 'react';
import { pwdgenAction } from "./pwdgenSlice";


const Pwdgen = () => {

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { sprofile } = useSelector((state) => state.profile);
    const { pwd } = useSelector((state) => state.passwordgenrator);
    const { token, fetchStatus } = useSelector((state) => state.login);


    // const [password, setPassword] = useState(pwd.password);
    const [pwdprofile, setPwdprofile] = useState({
        domain: '',
        lowerCase: sprofile.lowerCase,
        upperCase: sprofile.upperCase,
        digits: sprofile.digits,
        symbols: sprofile.digits,
        exclude: sprofile.exclude,
        revision: sprofile.revision,
        length: sprofile.length
    });



    const [submitted, setSubmitted] = useState(false);

    function handleChange(e) {
        const { name, value } = e.target;
        setPwdprofile(user => ({ ...user, [name]: value }));
        if (name === 'domain')
            handleChangeDomain(value).then(r => console.log("doamin loaded"));
    }

    function handleCheckbox(e) {
        const { name, value } = e.target;
        const newVal = !pwdprofile[name];
        setPwdprofile(user => ({ ...user, [name]: newVal }));
    }

    async function handleChangeDomain(value) {
        await dispatch(profileGetAction(value));
    }

    async function handleSubmit(e) {
        e.preventDefault();
        console.log("pwd gen submit called ");
        setSubmitted(true);
        try {
            let result = await dispatch(pwdgenAction(pwdprofile));
        } catch (error) {
            //TODO add error message
            // console.log("profile save  error");
        }


    }


    return (
        <>
        <h4>Password Generator</h4>
        <form name="form" onSubmit={handleSubmit}>
            <label htmlFor="domain">
                <span>Domain</span>
                <input type="text" name="domain" required="true" value={pwdprofile.domain} onChange={handleChange} />
            </label>
            <label htmlFor="isLower">

                <input type="checkbox" name="lowerCase" checked={pwdprofile.lowerCase} onChange={handleCheckbox} />
                <span> Include Lower Case</span>
            </label>
            <label htmlFor="isUpper">

                <input type="checkbox" name="uppercase" checked={pwdprofile.upperCase} onChange={handleCheckbox} />
                <span> Include Upper Case</span>
            </label>
            <label htmlFor="isSymbols">

                <input type="checkbox" name="symbols" checked={pwdprofile.symbols} onChange={handleCheckbox} />
                <span> Include Symbols </span>
                <span> !@#$%^&* []  </span>
            </label>
            <label htmlFor="isDigits">

                <input type="checkbox" name="digits" checked={pwdprofile.digits} onChange={handleCheckbox} />
                <span> Include Digits</span>
            </label>
            <label htmlFor="pwdLength">
                <span> Password Length  </span>
                <input type="number" name="length" min={6} value={pwdprofile.length} defaultChecked={true} onChange={handleChange} />
            </label>

            <label htmlFor="excludechars">
                Exclude characters
                <input type="text" name="exclude" value={pwdprofile.exclude} placeholder="Exclude Characters" onChange={handleChange} />
            </label>
            <label htmlFor="revision">
                <span> Revision  </span>
                <input type="number" name="revision" min={1} value={pwdprofile.revision} defaultChecked={true} onChange={handleChange} />
            </label>
            <button role="button" type="submit">Generate Password</button>
            <label htmlFor="Generated Password:">
                <input type="text" name="password" value={pwd.password} placeholder="Generated Password" readOnly={true} />
            </label>

        </form>
        </>
    );
};

export default Pwdgen;