
import React, { useState, useEffect } from 'react';
import { useNavigate,Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { registrationSlice } from "./registrationSlice";
import {registrationAction} from "./registrationSlice";
function Registration() {

    const [submitted, setSubmitted] = useState(false);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [user, setUser] = useState({
        firstName: '',
        lastName: '',
        name: '',
        email: '',
        credname:''
    });

    function handleChange(e) {
        const { name, value } = e.target;
        setUser(user => ({ ...user, [name]: value }));
    }


    async function handleSubmit(e) {
        e.preventDefault();
        try {
            setSubmitted(true);
            await dispatch(registrationAction(user));
            navigate("/login");
        } catch(error) {
            console.log("login error");
        }
    }

    return (

     <form name="form" onSubmit={handleSubmit}>
        <div className="form-group">
            <label htmlFor="FirstName">First Name</label>
            <input type="text" name="firstName" value={user.firstName} onChange={handleChange} className={'form-control' + (submitted && !user.firstName ? ' is-invalid' : '')} />
            {submitted && !user.firstName &&
                <div className="invalid-feedback">First Name is required</div>
            }
        </div>
        <div className="form-group">
            <label htmlFor="LastName">Last Name</label>
            <input type="text" name="lastName" value={user.lastName} onChange={handleChange} className={'form-control' + (submitted && !user.lastName ? ' is-invalid' : '')} />
            {submitted && !user.lastName &&
                <div className="invalid-feedback">Last Name is required</div>
            }
        </div>
        <div className="form-group">
            <label htmlFor="UserName">Username</label>
            <input type="text" name="name" value={user.name} onChange={handleChange} className={'form-control' + (submitted && !user.name ? ' is-invalid' : '')} />
            {submitted && !user.name &&
                <div className="invalid-feedback">Username is required</div>
            }
        </div>
        <div className="form-group">
            <label htmlFor="Email">email</label>
            <input type="email" name="email" value={user.email} onChange={handleChange} className={'form-control' + (submitted && !user.email ? ' is-invalid' : '')} />
            {submitted && !user.email &&
                <div className="invalid-feedback">email is required</div>
            }
        </div>
        <div className="form-group">
            <label htmlFor="DeviceName">Device Name</label>
            <input type="text" name="credname" value={user.credname} onChange={handleChange} className={'form-control' + (submitted && !user.credname ? ' is-invalid' : '')} />
            {submitted && !user.credname &&
                <div className="invalid-feedback">Device Name is required</div>
            }
        </div>
        <div className="form-group">
        <div className="grid">
            <button className="btn btn-primary" type='submit'>
                Register
            </button>
            <Link to="/logout" role="button" className='secondary' style={{ height: "63px" }}>Cancel</Link>
            </div>
        </div>
    </form>
    );
}

export default Registration;